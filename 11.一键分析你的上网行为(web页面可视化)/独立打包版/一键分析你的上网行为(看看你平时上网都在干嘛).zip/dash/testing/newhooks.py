def pytest_setup_options():
    """called before webdriver is initialized"""
